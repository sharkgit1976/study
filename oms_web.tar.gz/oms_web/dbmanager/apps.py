# coding:utf-8
from __future__ import unicode_literals

from django.apps import AppConfig


class DbmanagerConfig(AppConfig):
    name = 'dbmanager'
    verbose_name =u"数据库管理"

