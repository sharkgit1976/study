source /app/chdb/.bash_profileTuxCom JGGYSYS&
TuxCom JGGYSYS&
TuxCom JGGYSYS&
ps -ef|grep TuxCom|grep JGGYSYS|grep -v grep
