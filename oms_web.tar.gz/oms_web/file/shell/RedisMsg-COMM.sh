RedisMsg COMM  &
RedisMsg COMM  &
RedisMsg COMM  &
ps -ef|grep RedisMsg|grep COMM|grep -v grep
